package com.accubites.controllers;

import com.accubites.dto.RegistrationDTO;
import com.accubites.service.RegistrationServiceImpl;


@Controller
public class RegistretionController {
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		try {
			System.out.println("start of controller");

			
			
			String rfname = req.getParameter("firstname");
			String password = req.getParameter("password");
			String email = req.getParameter("email");
		
         	RegistrationDTO dto = new RegistrationDTO();
			
			dto.setEmail(email);
			dto.setName(name);
			dto.setPassword(password);
			

			
			RegistrationServiceImpl service = new RegistrationServiceImpl();
			service.save1(dto);
			System.out.println("end controller");

		   	
		
		
		} catch(Exception e) {
			e.printStackTrace();
			
			
		} 
		}

}
