package com.accubites.controllers;

import java.io.IOException;

import com.accubites.dto.LoginDTO;
import com.accubites.dto.RegistrationDTO;
import com.accubites.service.LoginServiceImpl;

@Controller
public class LoginController {
	
	
	
	 @RequestMapping("/login")    
	    public String showform(Model modal){    
	        modal.addAttribute("command", new LoginDTO());  
	        return "login.jsp";   
	    } 
	 

	 
	@Override
	protected <RequestDispatcher> void loginUser(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
	
		try {
			System.out.println("start of login controller");

			// firstname  password  are the id given to the fields in jspx page
			
			String loguser= req.getParameter("firstname");
			String logpasswd = req.getParameter("password");
        	LoginDTO dto = new LoginDTO();
			dto.setname(loguser);
			dto.setPassword(logpasswd);
            LoginServiceImpl service = new LoginServiceImpl();
			RegistrationDTO dto1=service.save1(dto);
			System.out.println("end of login controller");

		   	RequestDispatcher dispatch=null;
		   	
			if (dto1!=null) {
			

				RequestDispatcher rd = req
						.getRequestDispatcher("blog.jsp");
				rd.forward(req, resp);

			} else {
				
				RequestDispatcher rd = req
						.getRequestDispatcher("Failure.jsp");
				rd.forward(req, resp);

			}

			} catch(Exception e) {
			e.printStackTrace();
			
			
		} 

	}

}
