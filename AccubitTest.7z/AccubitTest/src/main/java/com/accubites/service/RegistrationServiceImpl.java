package com.accubites.service;

import com.accubites.dao.RegistrationDAOImpl;
import com.accubites.dto.RegistrationDTO;

public class RegistrationServiceImpl  implements RegistrationService {
	


	public void saveRegistratinDetail(RegistrationDTO dto) {
		// TODO Auto-generated method stub
		System.out.println("service method start");
		new RegistrationDAOImpl().save(dto);
		
		System.out.println("service method end");
		
	}
	
	

}
