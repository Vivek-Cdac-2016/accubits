package com.accubites.service;

import com.accubites.dto.RegistrationDTO;

public interface RegistrationService {

	public void saveRegistratinDetail(RegistrationDTO dto);
}
