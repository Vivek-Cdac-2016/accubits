package com.accubites.dao;

import com.accubites.dto.LoginDTO;
import com.accubites.dto.RegistrationDTO;

public interface LoginDAO {
	
	public RegistrationDTO authenticateUser(LoginDTO dto);

}
