package com.accubites.dto;

public class BlogDTO {
	
	private String title;
	private String blogdiscription;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBlogdiscription() {
		return blogdiscription;
	}
	public void setBlogdiscription(String blogdiscription) {
		this.blogdiscription = blogdiscription;
	}
	@Override
	public String toString() {
		return "Blog [title=" + title + ", blogdiscription=" + blogdiscription + "]";
	}
	
	

}
