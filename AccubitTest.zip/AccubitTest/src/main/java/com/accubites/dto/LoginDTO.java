package com.accubites.dto;
import java.io.Serializable;

public class LoginDTO implements Serializable  {

   private String name;
	private String password;

	public LoginDTO(){}

	public String getname() {
		return name;
	}

	public void setname(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	}


