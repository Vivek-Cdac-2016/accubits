package com.accubites.dao;

import com.accubites.dto.LoginDTO;
import com.accubites.dto.RegistrationDTO;

public class LoginDAOImpl {
	
	
public RegistrationDTO authenticateUser(LoginDTO dto){
		
		SessionFactory factory=ProjectUtil.getFactory(); 
		Session session=factory.openSession();
		
			System.out.println("entering method of fetchid of dao");
			String syntax="SELECT R from RegistrationDTO R where R.fname=:name and R.passwd=:pwd";
			factory =ProjectUtil.getFactory(); 
			session=factory.openSession();
			org.hibernate.Query query=session.createQuery(syntax);
			query.setParameter("name",dto.getUsername());
			query.setParameter("pwd", dto.getPassword());
			RegistrationDTO dtoFromDB=(RegistrationDTO)query.uniqueResult();
			try{
				if(dtoFromDB!=null){
					System.out.println("dto found");
					return dtoFromDB;
					
				}else{
					System.out.println("dto not found");
					
				}
				
				
				
			}catch(HibernateException he){
				he.printStackTrace();
				
			}
			finally{
				session.close();
				System.out.println("exiting method of fetchByNameAndId of dao");
			}
			return null;
			
		}


}
