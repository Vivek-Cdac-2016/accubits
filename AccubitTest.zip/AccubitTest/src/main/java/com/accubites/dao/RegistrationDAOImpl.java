package com.accubites.dao;

import javax.security.auth.login.Configuration;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.accubites.dto.RegistrationDTO;

public class RegistrationDAOImpl implements RegistrationDAO{{

	
	
		@Override
		public void save(RegistrationDTO dto) {
			// TODO Auto-generated method stub

			System.out.println("Enter into rgister dao save()");
			System.out.println(dto);
			try {

				if (dto != null) {
					System.out.println("Register" + dto.getName());
					Configuration cfg = new Configuration();
					/*cfg.configure();
					cfg.addAnnotatedClass(RegistrationDTO.class);
					SessionFactory factory = cfg.buildSessionFactory();*/
					SessionFactory factory =ProjectUtil.getFactory(); 
					Session session=factory.openSession();
					Transaction tx = session.beginTransaction();
					session.save(dto);
					tx.commit();
					session.close();

				}

			} catch (Exception e) {
				// TODO: handle exception
				System.err.println("Exception inside save persondao "
						+ e.getMessage());

				e.printStackTrace();
			}
			System.out.println("outside save RegisterDAO save()");

		}
}
