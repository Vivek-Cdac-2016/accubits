package com.accubites.dao;

public interface RegistrationDAO {

}
