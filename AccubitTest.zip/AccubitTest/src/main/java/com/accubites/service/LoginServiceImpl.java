package com.accubites.service;

import com.accubites.dao.LoginDAOImpl;
import com.accubites.dto.LoginDTO;
import com.accubites.dto.RegistrationDTO;

public class LoginServiceImpl {
	

public RegistrationDTO save1(LoginDTO dto){
		
		System.out.println("service method start");
	    LoginDAOImpl dao=new LoginDAOImpl();
		RegistrationDTO dto1=dao.authenticateUser(dto);
		System.out.println("service method end");
		return dto1;
		
		
	}
}
