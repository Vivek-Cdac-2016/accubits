package com.accubites.service;

import com.accubites.dto.LoginDTO;
import com.accubites.dto.RegistrationDTO;

public interface LoginService {

	
	public RegistrationDTO save1(LoginDTO dto);
}
